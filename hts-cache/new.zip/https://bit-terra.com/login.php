

<!DOCTYPE html>
<html lang="en" class="js">
<head>
	<meta charset="utf-8">
<meta name="author" content="Bitfinex Investment">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<!-- Fav Icon  -->
<link rel="shortcut icon" href="images/favicon.png">
<!-- Site Title  -->
<title>Login - Bit-terra Finance</title>
<!-- Bundle and Base CSS -->
<link rel="stylesheet" href="assets2/css/vendor.bundle.css?ver=192">
<link rel="stylesheet" href="assets2/css/style.css?ver=192" id="changeTheme">
<!-- Extra CSS -->
<link rel="stylesheet" href="assets2/css/theme.css?ver=192">


<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = "c859611da6152f4cde6a4c89599d15735041b545";
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName("script")[0];c=d.createElement("script");
  c.type="text/javascript";c.charset="utf-8";c.async=true;
  c.src="https://www.smartsuppchat.com/loader.js?";s.parentNode.insertBefore(c,s);
})(document);
</script>

</head>
   


    <body class="nk-body body-wider bg-light-alt">

	<div class="nk-wrap">
	    
        <main class="nk-pages">
            <div class="section">
                <div class="container">
                    <div class="nk-blocks d-flex justify-content-center">
                        <div class="ath-container m-0">
                            <div class="ath-body">
                                <a href="index.php">
                                    <!--<img src='images/logo.png'/>-->
                                    </a>
                                <h5 class="ath-heading title">Sign In</h5>
                                <form action="login.php" method="post">

                                    
                                

                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" name="details" placeholder="Username or Email">
                                        </div>
                                    </div> 
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="password" class="input-bordered" name="password" placeholder="Password">
                                        </div>
                                    </div>
                                    <div class="field-item d-flex justify-content-between align-items-center">
                                        <div class="field-item pb-0">
                                            <input class="input-checkbox" id="remember-me-100" type="checkbox">
                                            <label for="remember-me-100">Remember Me</label>
                                        </div>
                                        <div class="forget-link fz-6">
                                            <a href="forgot-password.php">Forgot password?</a>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block btn-md" style="width:100%;">Sign In</button>
                                </form>

                                <div class="ath-note text-center">
                                    Don’t have an account? <a href="signup.php"> <strong>Sign up here</strong></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
	</div>
	<div class="preloader"><span class="spinner spinner-round"></span></div>
	
	<!-- JavaScript -->
	<script src="assets2/js/jquery.bundle.js?ver=192"></script>
	<script src="assets2/js/scripts.js?ver=192"></script>
	<script src="assets2/js/charts.js"></script>
	    <!--<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="cf281c41-7d90-4677-b6d0-ed2de5c20f66";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>-->

</body>
</html>

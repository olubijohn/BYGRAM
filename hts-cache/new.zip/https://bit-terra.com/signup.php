


<!DOCTYPE html>
<html lang="en" class="js">
<head>
	<meta charset="utf-8">
	<meta name="robots" content="noindex">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="images/favicon.png">
    
    <!-- Site Title  -->
    <title>Signup - Bit-terra Finance</title>
    <!-- Bundle and Base CSS -->
    <link rel="stylesheet" href="assets2/css/vendor.bundle.css?ver=192">
    <link rel="stylesheet" href="assets2/css/style.css?ver=192" id="changeTheme">
    <!-- Extra CSS -->
    <link rel="stylesheet" href="assets2/css/theme.css?ver=192">
    
    
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = "c859611da6152f4cde6a4c89599d15735041b545";
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName("script")[0];c=d.createElement("script");
  c.type="text/javascript";c.charset="utf-8";c.async=true;
  c.src="https://www.smartsuppchat.com/loader.js?";s.parentNode.insertBefore(c,s);
})(document);
</script>
</head>
   


    <body class="nk-body body-wider bg-light-alt">

	<div class="nk-wrap">
	    
        <main class="nk-pages">
            <div class="section">
                <div class="container">
                    <div class="nk-blocks d-flex justify-content-center">
                        <div class="ath-container m-0">
                            <div class="ath-body">
                                <a href="index.php">
                                    <!--<img src='images/logo.png'/>-->
                                    </a>
                                <h5 class="ath-heading title">Sign Up</h5>
                                <form action="signup.php" method="post">
                                    
                                
                                
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Your Name" name="name" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Your Username" name="username" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Your Email" name="email" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Confirm Email Address" name="confirm-email" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Your Country" name="country" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Phone Number" name="phone" required="">
                                        </div>
                                    </div>
                                    <!--<div class="field-item">-->
                                    <!--    <div class="field-wrap">-->
                                    <!--        <input type="text" class="input-bordered" placeholder="Bitcoin Wallet" name="btcwallet">-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="password" class="input-bordered" placeholder="Password" name="password" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="password" class="input-bordered" placeholder="Repeat Password" name="confirm-password" required="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" placeholder="Referral Id (Optional)" name="ref" value="">
                                        </div>
                                    </div>
                                    <div class="field-item">
                                        <input class="input-checkbox" id="agree-term-2" type="checkbox" name="ac" value="v">
                                        <label for="agree-term-2">I agree to Bit-terra Finance <a href="#">Privacy Policy</a> &amp; <a href="#">Terms</a>.</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block btn-md" style="width:100%;">Sign Up</button>
                                </form>
                                
                                <div class="ath-note text-center">
                                    Already have an account? <a href="login.php"> <strong>Sign in here</strong></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
	</div>
	<div class="preloader"><span class="spinner spinner-round"></span></div>
	
	<!-- JavaScript -->
	<script src="assets2/js/jquery.bundle.js?ver=192"></script>
	<script src="assets2/js/scripts.js?ver=192"></script>
	<script src="assets2/js/charts.js"></script>
	    <!--<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="cf281c41-7d90-4677-b6d0-ed2de5c20f66";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>-->

</body>
</html>

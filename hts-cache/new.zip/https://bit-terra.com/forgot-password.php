

<!DOCTYPE html>
<html lang="en" class="js">
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<!-- Fav Icon  -->
<link rel="shortcut icon" href="images/favicon.png">
<!-- Site Title  -->
<title>Bit-terra Finance Investment</title>
<!-- Bundle and Base CSS -->
<link rel="stylesheet" href="assets2/css/vendor.bundle.css?ver=192">
<link rel="stylesheet" href="assets2/css/style.css?ver=192" id="changeTheme">
<!-- Extra CSS -->
<link rel="stylesheet" href="assets2/css/theme.css?ver=192">


<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = "c859611da6152f4cde6a4c89599d15735041b545";
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName("script")[0];c=d.createElement("script");
  c.type="text/javascript";c.charset="utf-8";c.async=true;
  c.src="https://www.smartsuppchat.com/loader.js?";s.parentNode.insertBefore(c,s);
})(document);
</script>



</head>
   


    <body class="nk-body body-wider bg-light-alt">
 
	<div class="nk-wrap">
		<header class="nk-header page-header is-transparent is-sticky is-shrink" id="header" style="background-color:#0a1227!important;">
		    <!-- Header @s -->
			<div class="header-main">
				<div class="header-container container">
					<div class="header-wrap">
						<!-- Logo @s -->
						<div class="header-logo logo">
							<a href="./" class="logo-link">
								<img class="logo-dark" src="logo.png" srcset="logo.png 2x" alt="logo" style="height:25px">
								<img class="logo-light" src="logo.png" srcset="logo.png 2x" alt="logo" style="height:25px">
							</a>
						</div>

						<!-- Menu Toogle @s -->
						<div class="header-nav-toggle">
							<a href="#" class="navbar-toggle" data-menu-toggle="header-menu">
                                <div class="toggle-line">
                                    <span></span>
                                </div>
                            </a>
						</div>

						<!-- Menu @s -->
						<div class="header-navbar">
							<nav class="header-menu" id="header-menu">
                                <ul class="menu">
                                    <li class="menu-item"><a class="menu-link nav-link" href="index.php#header">Home</a></li>
                                    <li class="menu-item"><a class="menu-link nav-link" href="index.php#about">About</a></li>
                                    <li class="menu-item"><a class="menu-link nav-link" href="index.php#features">Features</a></li>
                                    <li class="menu-item"><a class="menu-link nav-link" href="index.php#faq">FAQ</a></li>
                                    <li class="menu-item"><a href="login.php">Login</a></li>
                                </ul>

                                <ul class="menu-btns">
                                    <li><a href="signup.php" class="btn btn-md btn-auto btn-grad no-change"><span>Signup</span></a></li>
                                </ul>
                            </nav>
						</div><!-- .header-navbar @e -->
					</div>                                                
				</div>
			</div><!-- .header-main @e -->

			<!-- Banner @s -->
			<div class="header-banner" style="background-color:#0a1227!important;"></div>
			<!-- .header-banner @e -->
		</header>
    
        <main class="nk-pages">
            <div class="section">
                <div class="container">
                    <div class="nk-blocks d-flex justify-content-center">
                        <div class="ath-container m-0">
                            <div class="ath-body">
                                <h5 class="ath-heading title">Forgot Password</h5>
                                <small>Insert your email address below to reset your password</small>
                                <form action="" method="post">

                                    
                                

                                    <div class="field-item">
                                        <div class="field-wrap">
                                            <input type="text" class="input-bordered" name="email" placeholder="Email Address">
                                        </div>
                                    </div> 
                                    <button type="submit" class="btn btn-primary btn-block btn-md" style="width:100%;">Reset Password</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
	</div>
	<footer class="nk-footer bg-theme-grad">
            
			<section class="section section-footer tc-light bg-transparent">
			
				<div class="container">
				    <!-- Block @s -->
					<div class="nk-block block-footer mgb-m30">
                        <div class="row">
                            
                            <div class="col-lg-2 col-sm-4">
                                <div class="wgs wgs-menu animated" data-animate="fadeInUp" data-delay=".3">
                                    <h6 class="wgs-title">Legal</h6>
                                    <div class="wgs-body">
                                        <ul class="wgs-links">
                                            <li>Terms &amp; Conditions</a></li>
                                            <li>Privacy Policy</a></li>
                                            <li>Terms of Sales</a></li>
                                            <li><a href="WhitePaper.pdf"><b>Whitepaper</b></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!-- .col -->
                            
                            <div class="col-lg-6 order-lg-first">
                                <div class="wgs wgs-text animated" data-animate="fadeInUp" data-delay=".1">
                                    <div class="wgs-body">
                                        <a href="./" class="wgs-logo">
                                            <img src="logo.svg" srcset="logo.svg 2x" alt="logo" style="height:25px;">
                                        </a>
                                        <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

                                    </div>
                                </div>
                            </div><!-- .col -->
                        </div><!-- .row -->
					</div><!-- .block @e -->
				</div>
				
			</section>
			<div class="nk-ovm shape-b"></div>
		</footer>
	<div class="preloader"><span class="spinner spinner-round"></span></div>
	
	<!-- JavaScript -->
	<script src="assets2/js/jquery.bundle.js?ver=192"></script>
	<script src="assets2/js/scripts.js?ver=192"></script>
	<script src="assets2/js/charts.js"></script>
</body>
</html>
